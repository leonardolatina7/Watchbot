# 🚀 Deploy su Render.com — Solo dal telefono

## Cosa ti serve prima di iniziare
- Account Gmail (probabilmente ce l'hai già)
- 20 minuti

---

## STEP 1 — Credenziali eBay (5 min, gratis)

1. Vai su **developer.ebay.com** dal browser
2. Clicca "Sign In" → accedi con un account eBay (o creane uno)
3. Clicca **"Get an Application Key"**
4. Nome app: `watch-price-bot` → Accept → Create
5. Vai su **"Application Keys"** → copia:
   - **App ID (Client ID)** → salvalo
   - **Cert ID (Client Secret)** → salvalo
6. Assicurati di essere su **"Production"** (non Sandbox)

---

## STEP 2 — App Password Gmail (3 min)

1. Vai su **myaccount.google.com**
2. Sicurezza → Verifica in 2 passaggi → attivala se non l'hai
3. Torna su Sicurezza → cerca **"Password per le app"**
4. Seleziona "Altra app" → scrivi "watch-bot" → Genera
5. Copia la password a **16 caratteri** → salvala

---

## STEP 3 — Carica su GitHub (5 min)

1. Vai su **github.com** → Sign Up (gratis)
2. Clicca **"+"** → **"New repository"**
3. Nome: `watch-price-bot` → Public → **"Create repository"**
4. Clicca **"uploading an existing file"**
5. Carica TUTTI i file dello ZIP:
   - `server/index.js`
   - `server/package.json`
   - `server/.env.example`
   - `client/App.jsx`
   - `render.yaml`
   - `.gitignore`
6. Clicca **"Commit changes"** → fatto ✅

---

## STEP 4 — Deploy su Render (5 min, gratis)

1. Vai su **render.com** → **"Get Started for Free"**
2. Clicca **"Sign in with GitHub"** → autorizza
3. Clicca **"New +"** → **"Web Service"**
4. Seleziona il repository `watch-price-bot`
5. Render rileva automaticamente `render.yaml` ✅
6. Vai su **"Environment"** e aggiungi le variabili:

   | Chiave | Valore |
   |--------|--------|
   | EBAY_CLIENT_ID | (il tuo Client ID eBay) |
   | EBAY_CLIENT_SECRET | (il tuo Cert ID eBay) |
   | SMTP_USER | tuaemail@gmail.com |
   | SMTP_PASS | (la password 16 caratteri) |

7. Clicca **"Create Web Service"**
8. Aspetta 3-4 minuti → il bot è online! 🟢

Il tuo URL sarà tipo: `https://watch-price-bot-gold-xxxx.onrender.com`

---

## STEP 5 — Tienilo sveglio (2 min, gratis)

Il piano gratuito di Render si addormenta dopo 15 min.
Soluzione gratuita: cron-job.org fa un "ping" ogni 10 minuti.

1. Vai su **cron-job.org** → Sign Up (gratis)
2. Clicca **"Create cronjob"**
3. URL: `https://IL-TUO-URL.onrender.com/api/status`
4. Esecuzione: ogni **10 minuti**
5. Salva → il bot resta sempre sveglio ✅

---

## STEP 6 — Verifica che tutto funzioni

Apri dal browser:
```
https://IL-TUO-URL.onrender.com/api/status
```

Dovresti vedere qualcosa tipo:
```json
{
  "status": "online",
  "platforms": 10,
  "goldPricePerGram": 78.45,
  "ebayConfigured": true,
  "emailConfigured": true
}
```

---

## STEP 7 — Avvia la prima scansione arbitraggio oro

Apri dal browser:
```
https://IL-TUO-URL.onrender.com/api/gold-scan
```

Aspetta 2 minuti → poi vai su:
```
https://IL-TUO-URL.onrender.com/api/arbitrage
```

Vedrai gli orologi 18k trovati sotto il valore spot dell'oro! 🥇

---

## Credenziali opzionali (consigliate)

### Metals API — prezzo oro in tempo reale
- Vai su **metals-api.com** → Sign Up (gratis, 250 req/mese)
- Copia l'API key → aggiungila su Render come `METALS_API_KEY`
- Senza questa chiave il bot usa goldprice.org come backup automatico

---

## Aggiornare il frontend

Nel file `client/App.jsx`, cambia la prima riga:
```js
const API_BASE = "https://IL-TUO-URL.onrender.com/api";
```

Poi ricarica la pagina su Claude.ai e il frontend si collegherà al tuo server reale.

---

## Cosa succede automaticamente

| Ogni | Cosa fa |
|------|---------|
| 30 min | Scansiona tutti gli orologi in watchlist su 10 piattaforme |
| 2 ore | Scansione dedicata arbitraggio oro (Rolex, Patek, AP, Cartier...) |
| Sempre | Alert email se trova orologi sotto soglia o sotto valore oro |
